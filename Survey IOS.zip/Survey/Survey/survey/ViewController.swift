//
//  ViewController.swift
//  survey
//
//  Created by William Yip on 18/05/2017.
//  Copyright © 2017 William Yip. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    var addSurvey: [NSManagedObject] = []
    
    @IBOutlet weak var sliderValue: UISlider!
    @IBOutlet weak var year: UILabel!
    @IBOutlet weak var safetyLevel: UISegmentedControl!
    @IBOutlet weak var neighbours: UISegmentedControl!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    @IBAction func getSliderValue(_ sender: Any) {
        var slider = Int(sliderValue.value)
        year.text = "\(slider)"
    }
    
    
    @IBAction func addSurvey(_ sender: Any) {
        let live = Int(year.text!)
        let know = neighbours.titleForSegment(at: neighbours.selectedSegmentIndex)
        let safety  = Int(safetyLevel.titleForSegment(at: safetyLevel.selectedSegmentIndex)!)
        
        // Core Data
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let entity = NSEntityDescription.entity(forEntityName: "Entity",
                                                in: managedContext)!
        let survey = NSManagedObject(entity: entity,
                                   insertInto: managedContext)
        
        survey.setValue(live, forKeyPath: "live")
        survey.setValue(know,forKeyPath: "know")
        survey.setValue(safety,forKeyPath: "safety")
        
        do{
            try managedContext.save()
            self.addSurvey.append(survey)
        }catch let error as NSError {
            print("Could not save. \(error), \(error.userInfo)")
        }
        
        self.navigationController?.popViewController(animated: true)
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


