// william 13112223

package com.example.william.foodhygieneratings;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

public class JSONParser {

    JSONArray jArray = null;

    // constructor
    public JSONParser() {

    }

    public JSONArray getJSONFromUrl(String strUrl) {

        // Making HTTP request
        String result;
        try {
            URL url = new URL(strUrl);
            URLConnection urlConn = url.openConnection();
            BufferedReader reader = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
            StringBuilder sb = new StringBuilder();

            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
            //is.close();
            // String builder to string
            result = sb.toString();
            // Make string into JSON Array
            jArray = new JSONArray(result);

        } catch (Exception e) {
            System.err.println("PROBLEM FOUND JSON");
        }
        return jArray;

    }
}
