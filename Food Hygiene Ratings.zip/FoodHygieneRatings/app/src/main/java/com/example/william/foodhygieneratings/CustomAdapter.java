// william 13112223

package com.example.william.foodhygieneratings;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class CustomAdapter extends BaseAdapter {

    private Activity activity;
    private ArrayList<HashMap<String, String>> data;
    private static LayoutInflater inflater = null;

    public CustomAdapter(Activity a, ArrayList<HashMap<String, String>> d) {
        activity = a;
        data = d;
        inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    public int getCount() {
        return data.size();
    }

    public Object getItem(int position) {
        return position;
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView = convertView;
        if (convertView == null)
            rowView = inflater.inflate(R.layout.list_item, null);

        // Get TextViews from list_item.xml
        TextView id = (TextView) rowView.findViewById(R.id.id);
        TextView businessName = (TextView) rowView.findViewById(R.id.BusinessName);
        TextView addressLine1 = (TextView) rowView.findViewById(R.id.AddressLine1);
        TextView addressLine2 = (TextView) rowView.findViewById(R.id.AddressLine2);
        TextView addressLine3 = (TextView) rowView.findViewById(R.id.AddressLine3);
        TextView postCode = (TextView) rowView.findViewById(R.id.PostCode);
        TextView ratingDate = (TextView) rowView.findViewById(R.id.RatingDate);
        TextView distanceKM = (TextView) rowView.findViewById(R.id.DistanceKM);
        TextView latLong = (TextView) rowView.findViewById(R.id.LatLong);
        // Get ImageView from list_item.xml
        ImageView ratingValue = (ImageView) rowView.findViewById(R.id.RatingValue);

        HashMap<String, String> row;
        row = data.get(position);

        // Setting all values in listview
        id.setText(row.get("id"));
        businessName.setText(row.get("BusinessName"));
        addressLine1.setText(row.get("AddressLine1"));
        addressLine2.setText(row.get("AddressLine2"));
        addressLine3.setText(row.get("AddressLine3"));
        postCode.setText(row.get("PostCode"));
        ratingDate.setText(row.get("RatingDate"));

        // If distance exists then show else remove the row
        if (row.get("DistanceKM") != null){
            distanceKM.setText("Distance: " + row.get("DistanceKM"));
        } else {
            distanceKM.setVisibility(View.GONE);
        }

        latLong.setText("lat,long: " + row.get("Latitude") + "," + row.get("Longitude"));

        //duration.setText(song.get(CustomizedListView.KEY_DURATION));
        if (row.get("RatingValue").equals("0")) {
            ratingValue.setImageResource(R.mipmap.rating0);
        } else if (row.get("RatingValue").equals("1")) {
            ratingValue.setImageResource(R.mipmap.rating1);
        } else if (row.get("RatingValue").equals("2")) {
            ratingValue.setImageResource(R.mipmap.rating2);
        } else if (row.get("RatingValue").equals("3")) {
            ratingValue.setImageResource(R.mipmap.rating3);
        } else if (row.get("RatingValue").equals("4")) {
            ratingValue.setImageResource(R.mipmap.rating4);
        } else if (row.get("RatingValue").equals("5")) {
            ratingValue.setImageResource(R.mipmap.rating5);
        }else if (row.get("RatingValue").equals("-1")) {
            ratingValue.setImageResource(R.mipmap.exempt);
        }
        return rowView;
    }
}
