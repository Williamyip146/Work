// william 13112223

package com.example.william.foodhygieneratings;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    ArrayList<HashMap<String, String>> listRating = new ArrayList<>();
    private JSONArray json;
    private String url = "http://sandbox.kriswelsh.com/hygieneapi/hygiene.php?op=s_";
    double lat, lon;
    private boolean gps_enabled = false, isLocationSearch;
    private LocationManager locMan;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        final TextView currentLat = (TextView) findViewById(R.id.latitudeValue);
        final TextView currentLon = (TextView) findViewById(R.id.longitudeValue);

        Context context = this.getApplicationContext();
        locMan = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);

        // Location Listener
        try {
            locMan.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    // get users current lat and lon and set the textviews
                    lat = location.getLatitude();
                    lon = location.getLongitude();
                    System.out.println("THE LAT " + location.getLatitude());
                    System.out.println("THE Long " + lon);
                    NumberFormat nm = NumberFormat.getNumberInstance();
                    currentLat.setText(nm.format(lat));
                    currentLon.setText(nm.format(lon));
                }

                @Override
                public void onStatusChanged(String provider, int status, Bundle extras) {

                }

                @Override
                public void onProviderEnabled(String provider) {
                    // Tell user getting GPS location when
                    currentLat.setText(R.string.latitude_value);
                    currentLon.setText(R.string.longitude_value);
                }

                @Override
                public void onProviderDisabled(String provider) {
                    // Show when GPS is disbaled
                    currentLat.setText(R.string.gps_off);
                    currentLon.setText(R.string.gps_off);
                }
            });


        } catch (SecurityException e) {
            System.err.println("ERROR GPS LOCATION");
        }

    }

    public void onClickLocation(View v) {
        isLocationSearch = true;

        // Check if GPS is available
        try {
            gps_enabled = locMan.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception ex) {
            System.err.println("Error catching GPS");
        }
        if (gps_enabled && haveInternetConnection()) {
            // Convert double lat and long into string and create URL
            String strLat = String.valueOf(lat);
            String strLon = String.valueOf(lon);
            String urlLoc = url + "loc&lat=" + strLat + "&long=" + strLon;
            new JSONParse().execute(urlLoc);
        } else if (!gps_enabled && haveInternetConnection()) {
            Toast.makeText(MainActivity.this, "GPS is Disabled!!",
                    Toast.LENGTH_LONG).show();
        } else if (!haveInternetConnection() && gps_enabled) {
            Toast.makeText(MainActivity.this, "No Internet!!",
                    Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(MainActivity.this, "GPS is Disabled And No Internet!!",
                    Toast.LENGTH_LONG).show();
        }

    }

    public void onClickName(View v) {
        // Set location search to false
        isLocationSearch = false;
        // Get User Input
        EditText test = (EditText) findViewById(R.id.nameInput);
        String userInput = test.getText().toString();
        if (userInput.length() <= 2) {
            Toast.makeText(MainActivity.this, "Make sure name is greater than 2 characters",
                    Toast.LENGTH_LONG).show();
        } else {
            // Replace space with %20 to get valid URL
            userInput = userInput.replaceAll(" ", "%20");
            String urlName = url + "name&name=" + userInput;
            new JSONParse().execute(urlName);
        }
    }

    public void onClickPostcode(View v) {
        // set Location search to false
        isLocationSearch = false;
        // Get user input
        EditText nameInput = (EditText) findViewById(R.id.nameInput);
        String userInput = nameInput.getText().toString();
        //haveInternetConnection();
        if (userInput.length() <= 2) {
            Toast.makeText(MainActivity.this, "Make sure postcode is greater than 2 characters",
                    Toast.LENGTH_LONG).show();
        } else if (!haveInternetConnection()) {
            Toast.makeText(MainActivity.this, "No Internet",
                    Toast.LENGTH_LONG).show();
        } else {
            // Replace space with %20 to get valid URL
            userInput = userInput.replaceAll(" ", "%20");
            String urlName = url + "postcode&postcode=" + userInput;
            new JSONParse().execute(urlName);
        }
    }

    private boolean haveInternetConnection() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();

        // if no activenetworkInfo then = null and returns false
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    private class JSONParse extends AsyncTask<String, String, JSONArray> {
        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Create loading dialog
            progressDialog = new ProgressDialog(MainActivity.this);
            progressDialog.setMessage("Getting Results ...");
            progressDialog.setIndeterminate(false);
            progressDialog.setCancelable(true);
            progressDialog.show();

        }

        @Override
        protected JSONArray doInBackground(String... params) {
            JSONParser jParser = new JSONParser();
            // Getting JSON from URL
            json = jParser.getJSONFromUrl(params[0]);
            return json;
        }

        @Override
        protected void onPostExecute(JSONArray json) {
            // Stop loading dialog
            progressDialog.dismiss();
            // Clear list so new items dont stack on old items
            listRating.clear();

            // If no data results found show Toast message else display the results
            if (json.length() == 0) {
                Toast.makeText(MainActivity.this, "No Results Found",
                        Toast.LENGTH_LONG).show();
            } else {
                try {
                    for (int i = 0; i < json.length(); i++) {
                        JSONObject jo = (JSONObject) json.get(i);
                        String id = jo.getString("id");
                        String businessName = jo.getString("BusinessName");
                        String addressLine1 = jo.getString("AddressLine1");
                        String addressLine2 = jo.getString("AddressLine2");
                        String addressLine3 = jo.getString("AddressLine3");
                        String postCode = jo.getString("PostCode");
                        String ratingValue = jo.getString("RatingValue");
                        String ratingDate = jo.getString("RatingDate");
                        String latitude = jo.getString("Latitude");
                        String longitude = jo.getString("Longitude");

                        HashMap<String, String> map = new HashMap<>();

                        map.put("id", id);
                        map.put("BusinessName", businessName);
                        map.put("AddressLine1", addressLine1);
                        map.put("AddressLine2", addressLine2);
                        map.put("AddressLine3", addressLine3);
                        map.put("PostCode", postCode);
                        map.put("RatingValue", ratingValue);
                        map.put("RatingDate", ratingDate);
                        map.put("Latitude", latitude);
                        map.put("Longitude", longitude);
                        // If the location button is pressed then do this
                        if (isLocationSearch) {
                            String distanceKM = jo.getString("DistanceKM");
                            map.put("DistanceKM", distanceKM);
                        }

                        listRating.add(map);

                    }

                    // Getting adapter by passing xml data ArrayList
                    ListView list = (ListView) findViewById(R.id.listView);
                    CustomAdapter adapter = new CustomAdapter(MainActivity.this, listRating);
                    list.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                    System.err.println("Error Adapter");
                }
            }
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_map) {
            if (json == null || json.length() == 0) {
                Toast.makeText(MainActivity.this, "No Results To Display On Map!",
                        Toast.LENGTH_LONG).show();
            } else {
                Intent intent = new Intent(MainActivity.this, MapsActivity.class);
                intent.putExtra("jsonArray", json.toString());
                startActivity(intent);
            }
        } else if (id == R.id.clear) {
            // clear listview, jsonArray and hashmap
            listRating.clear();
            json = new JSONArray();
            ListView list = (ListView) findViewById(R.id.listView);
            // clear list by creating list of empty data
            CustomAdapter adapter = new CustomAdapter(MainActivity.this, listRating);
            list.setAdapter(adapter);

        }
        return super.onOptionsItemSelected(item);
    }
}
