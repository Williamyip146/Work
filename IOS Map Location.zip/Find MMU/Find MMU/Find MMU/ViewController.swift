//
//  ViewController.swift
//  Find MMU
//
//  Created by William Yip on 09/05/2017.
//  Copyright © 2017 William Yip. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {

    @IBOutlet weak var mapView: MKMapView!
    private let locationManager = CLLocationManager()
    
    var startPoint = MKPointAnnotation()
    var endPoint = MKPointAnnotation()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
        // Do any additional setup after loading the view, typically from a nib.
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        
        // add Macclesfield
        startPoint = MKPointAnnotation()
        startPoint.coordinate = CLLocationCoordinate2DMake(53.2586630, -2.119827);
        startPoint.title = "Macclesfield!"
        mapView.addAnnotation(startPoint)
        
        //add mmu
        endPoint = MKPointAnnotation()
        endPoint.coordinate = CLLocationCoordinate2DMake(53.471872, -2.239934);
        endPoint.title = "MMU!"
        mapView.addAnnotation(endPoint)
        
        giveDirection()
        
    }
    
    func giveDirection(){
        let request = MKDirectionsRequest()
        request.source = MKMapItem(placemark: MKPlacemark(coordinate:(startPoint.coordinate)))
        
        request.destination =
            MKMapItem(placemark: MKPlacemark(coordinate:(endPoint.coordinate)))
        request.requestsAlternateRoutes = true
        request.transportType = .automobile
        
        let directions = MKDirections(request: request)
        directions.calculate { [unowned self] response, error in
            if let response = response{
                if let route = response.routes.first {
                    self.mapView.add(route.polyline)
                    self.mapView.setVisibleMapRect(
                        route.polyline.boundingMapRect, animated:
                        true)
                }
            }
        }
    }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        if overlay is MKPolyline {
            let polylineRenderer = MKPolylineRenderer(overlay: overlay)
            polylineRenderer.strokeColor = UIColor.red
            polylineRenderer.lineWidth = 5
            return polylineRenderer
        }
        return MKOverlayRenderer()
    }
    
    func locationManager(_ manager:CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus)
    {
        print("Authorization status changed to \(status)")
        switch status {
        case .authorizedAlways, . authorizedWhenInUse:
            locationManager.startUpdatingLocation()
        default:
            locationManager.stopUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
  //      if let location = locations.last{
            
//            latitudeLabel.text = location.latitude.description
//            longitudeLabel.text = location.longitude.description
            
  //      }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

