README

#Project - William_Yip_13112223

## URL - http://1-dot-testing-155412.appspot.com/

## Tab - Search

## Type in the search Bar - Computing or Web Development(case sensitive)
## Select  which DataType - JSON, XML, TEXT
## You should be able to see Data within the box

## Tab - Add Course

## Type Course ID, Course Title, Course Credits, Course Duration, Tutor
## Example: AK47OOSH , Police, 10, 20, Paul James 
## Wait for the alert("You have added a new Course")

## Tab - List Course

## Click All Courses
## Wait this can take 10-20seconds (Don't why is so slow)
## Display a list of Courses



### View Single Course  XML, JSON AND TEXT

### URL - http://1-dot-testing-155412.appspot.com/SearchController?search=Computing&courseOp=XML
### Change - courseOp=JSON, courseOp=XML or courseOp=TEXT


### View All Course XML, JSON AND TEXT

### URL - http://1-dot-testing-155412.appspot.com/GetAllCourses?allcourses=all&OpType=xml
### Change - courseOp=JSON, courseOp=xml or courseOp=TEXT


Project - RestFullDemo


## Right Click RestFullDemo select Run As  - Run On Server
## URL - http://localhost:8080/RestFullDemo/YourName/William/text

### You can Replace William any Name you want 

### You can change text into json, text, html and xml